# Ansible Collection - zergsoft.utilities

Collection of utilites.  Currently, only one :-).

# roles:
`manage_external_roles`

Import arbitrary versions of arbitrary roles from git repositories.   
