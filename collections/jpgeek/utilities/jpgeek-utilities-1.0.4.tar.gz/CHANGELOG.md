2024/01/11      v 1.0.1     initial release
2024/01/12      v 1.0.2     rename directory tmp to `external_roles_tmp`
2024/01/14      v 1.0.3     rewrite much of the code.
2024/01/15      v 1.0.4     bug fix in role directory layout.
